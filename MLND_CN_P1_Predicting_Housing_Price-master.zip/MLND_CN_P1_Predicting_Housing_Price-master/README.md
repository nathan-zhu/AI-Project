# MLND_CN_P1_Predicting_Housing_Price
nd009-cn-advanced-p1，针对Udacity CN MLND P1项目


你需要的一切都在 `boston_housing.ipynb`

Enjoy coding!!!